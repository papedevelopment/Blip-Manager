-- ██████╗ ██╗     ██╗██████╗     ███╗   ███╗ █████╗ ███╗   ██╗ █████╗  ██████╗ ███████╗██████╗ 
-- ██╔══██╗██║     ██║██╔══██╗    ████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗
-- ██████╔╝██║     ██║██████╔╝    ██╔████╔██║███████║██╔██╗ ██║███████║██║  ███╗█████╗  ██████╔╝
-- ██╔══██╗██║     ██║██╔═══╝     ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██╔══██╗
-- ██████╔╝███████╗██║██║         ██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██║╚██████╔╝███████╗██║  ██║
-- ╚═════╝ ╚══════╝╚═╝╚═╝         ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
-- By Pape Development

local blips = {}

local ESX, QBCore = nil, nil

Citizen.CreateThread(function()
    if Config.PermissionSystem == 'esx' then
        while ESX == nil do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            if ESX == nil then
                ESX = exports['es_extended']:getSharedObject()
            end
            Citizen.Wait(100)
        end
        print('[^2BlipManager^7] ESX detected and loaded')
    elseif Config.PermissionSystem == 'qb' then
        QBCore = exports['qb-core']:GetCoreObject()
        print('[^2BlipManager^7] QB-Core detected and loaded')
    elseif Config.PermissionSystem == 'ace' then
        print('[^2BlipManager^7] Using ACE permissions')
    elseif Config.PermissionSystem == 'custom' then
        print('[^2BlipManager^7] Using custom permission system')
    end
end)

local function HasPermission(source)
    local src = source
    
    if Config.PermissionSystem == 'esx' then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local group = xPlayer.getGroup()
            for _, allowedGroup in ipairs(Config.ESXAllowedGroups) do
                if group == allowedGroup then
                    return true
                end
            end
        end
        return false
        
    elseif Config.PermissionSystem == 'qb' then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local permission = QBCore.Functions.GetPermission(src)
            for _, allowedGroup in ipairs(Config.QBAllowedGroups) do
                if permission == allowedGroup or QBCore.Functions.HasPermission(src, allowedGroup) then
                    return true
                end
            end
        end
        return false
        
    elseif Config.PermissionSystem == 'ace' then
        return IsPlayerAceAllowed(src, Config.AcePermission)
        
    elseif Config.PermissionSystem == 'custom' then
        return Config.CustomPermissionCheck(src)
    end
    
    return false
end

RegisterNetEvent('pape_blipmanager:checkPermission')
AddEventHandler('pape_blipmanager:checkPermission', function()
    local src = source
    
    if HasPermission(src) then
        TriggerClientEvent('pape_blipmanager:permissionGranted', src)
    else
        TriggerClientEvent('pape_blipmanager:permissionDenied', src)
    end
end)

local function LoadBlipsFromDatabase()
    exports.oxmysql:query('SELECT * FROM custom_blips', {}, function(results)
        if results then
            for _, row in ipairs(results) do
                local blipData = {
                    uid = row.uid,
                    title = row.title,
                    id = row.sprite,
                    colour = row.colour,
                    x = row.x,
                    y = row.y,
                    z = row.z
                }
                blips[row.uid] = blipData
            end
            print(('[^2BlipManager^7] Loaded ^3%d^7 blips from database'):format(#results))
        end
    end)
end

local function SaveBlipToDatabase(blipData)
    exports.oxmysql:insert('INSERT INTO custom_blips (uid, title, sprite, colour, x, y, z) VALUES (?, ?, ?, ?, ?, ?, ?)', {
        blipData.uid,
        blipData.title,
        blipData.id,
        blipData.colour,
        blipData.x,
        blipData.y,
        blipData.z
    }, function(id)
        if id then
            print(('[^2BlipManager^7] Saved blip to database: ^3%s^7'):format(blipData.title))
        else
            print(('[^1BlipManager^7] Failed to save blip: ^3%s^7'):format(blipData.title))
        end
    end)
end

local function DeleteBlipFromDatabase(uid)
    exports.oxmysql:query('DELETE FROM custom_blips WHERE uid = ?', { uid }, function(result)
        if result then
            print(('[^2BlipManager^7] Deleted blip from database: ^3%s^7'):format(uid))
        end
    end)
end

CreateThread(function()
    Wait(1000)
    LoadBlipsFromDatabase()
end)

RegisterNetEvent('pape_blipmanager:createBlip')
AddEventHandler('pape_blipmanager:createBlip', function(blipData)
    local src = source
    
    if not HasPermission(src) then
        print(('[^1BlipManager^7] Unauthorized blip creation attempt by player ^3%s^7'):format(src))
        return
    end
    
    blips[blipData.uid] = blipData
    SaveBlipToDatabase(blipData)
    TriggerClientEvent('pape_blipmanager:syncBlip', -1, blipData)
    
    print(('[^2BlipManager^7] Blip created: ^3%s^7 by player ^3%s^7'):format(blipData.title, src))
end)

RegisterNetEvent('pape_blipmanager:deleteBlip')
AddEventHandler('pape_blipmanager:deleteBlip', function(uid)
    local src = source
    
    if not HasPermission(src) then
        print(('[^1BlipManager^7] Unauthorized blip deletion attempt by player ^3%s^7'):format(src))
        return
    end
    
    if blips[uid] then
        print(('[^2BlipManager^7] Blip deleted: ^3%s^7 by player ^3%s^7'):format(blips[uid].title, src))
        blips[uid] = nil
    end
    
    DeleteBlipFromDatabase(uid)
    TriggerClientEvent('pape_blipmanager:removeBlip', -1, uid)
end)

RegisterNetEvent('pape_blipmanager:requestBlips')
AddEventHandler('pape_blipmanager:requestBlips', function()
    local src = source
    
    local blipArray = {}
    for uid, data in pairs(blips) do
        table.insert(blipArray, data)
    end
    
    TriggerClientEvent('pape_blipmanager:loadBlips', src, blipArray)
end)
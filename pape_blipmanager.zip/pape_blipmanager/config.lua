Config = {}

-- ██████╗ ██╗     ██╗██████╗     ███╗   ███╗ █████╗ ███╗   ██╗ █████╗  ██████╗ ███████╗██████╗ 
-- ██╔══██╗██║     ██║██╔══██╗    ████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗
-- ██████╔╝██║     ██║██████╔╝    ██╔████╔██║███████║██╔██╗ ██║███████║██║  ███╗█████╗  ██████╔╝
-- ██╔══██╗██║     ██║██╔═══╝     ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██╔══██╗
-- ██████╔╝███████╗██║██║         ██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██║╚██████╔╝███████╗██║  ██║
-- ╚═════╝ ╚══════╝╚═╝╚═╝         ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
-- By Pape Development

-----------------------------------------------------------------
-- PERMISSION SYSTEM
-----------------------------------------------------------------

-- Choose your permission system: 'esx', 'qb', 'ace', 'custom'
Config.PermissionSystem = 'esx'

-----------------------------------------------------------------
-- ESX GROUPS (if using 'esx' permission system)
-----------------------------------------------------------------
-- Add the ESX job groups that can access the blip manager
Config.ESXAllowedGroups = {
    'admin',
    'management',
    -- Add more groups as needed
}

-----------------------------------------------------------------
-- QB-CORE PERMISSIONS (if using 'qb' permission system)
-----------------------------------------------------------------
-- Add the QB-Core permissions that can access the blip manager
Config.QBAllowedGroups = {
    'admin',
    'god',
    'mod',
    -- Add more groups as needed
}

-----------------------------------------------------------------
-- ACE PERMISSIONS (if using 'ace' permission system)
-----------------------------------------------------------------
-- The ACE permission required to access the blip manager
Config.AcePermission = 'blipmanager.access'

-----------------------------------------------------------------
-- COMMAND SETTINGS
-----------------------------------------------------------------

-- Command to open the blip manager
Config.Command = 'blipmanager'

-- Command suggestion description
Config.CommandSuggestion = 'Open Blip Manager'

-----------------------------------------------------------------
-- NOTIFICATIONS
-----------------------------------------------------------------

-- Notification when player doesn't have permission
Config.NoPermissionMessage = 'You do not have permission to access the Blip Manager.'

-- Use ox_lib notifications (set to false for default chat message)
Config.UseOxLibNotify = false
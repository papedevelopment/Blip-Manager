fx_version 'bodacious'
game 'gta5'

author 'Pape Development'
description 'Admin Blip Management System'
version '1.0.0'

lua54 'yes'

dependency 'oxmysql'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
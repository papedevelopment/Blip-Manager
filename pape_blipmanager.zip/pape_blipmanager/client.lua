-- ██████╗ ██╗     ██╗██████╗     ███╗   ███╗ █████╗ ███╗   ██╗ █████╗  ██████╗ ███████╗██████╗ 
-- ██╔══██╗██║     ██║██╔══██╗    ████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗
-- ██████╔╝██║     ██║██████╔╝    ██╔████╔██║███████║██╔██╗ ██║███████║██║  ███╗█████╗  ██████╔╝
-- ██╔══██╗██║     ██║██╔═══╝     ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██╔══██╗
-- ██████╔╝███████╗██║██║         ██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██║╚██████╔╝███████╗██║  ██║
-- ╚═════╝ ╚══════╝╚═╝╚═╝         ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
-- By Pape Development

local blips = {}
local blipHandles = {}
local isUIOpen = false

local function CreateBlip(data)
    local blip = AddBlipForCoord(data.x, data.y, data.z)
    SetBlipSprite(blip, data.id)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 1.0)
    SetBlipColour(blip, data.colour)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(data.title)
    EndTextCommandSetBlipName(blip)
    return blip
end

local function Notify(message, type)
    if Config.UseOxLibNotify then
        exports['ox_lib']:notify({
            title = 'Blip Manager',
            description = message,
            type = type or 'error'
        })
    else
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {'Blip Manager', message}
        })
    end
end

RegisterCommand(Config.Command, function()
    if isUIOpen then
        CloseBlipUI()
    else
        TriggerServerEvent('pape_blipmanager:checkPermission')
    end
end, false)

TriggerEvent('chat:addSuggestion', '/' .. Config.Command, Config.CommandSuggestion)

RegisterNetEvent('pape_blipmanager:permissionGranted')
AddEventHandler('pape_blipmanager:permissionGranted', function()
    OpenBlipUI()
end)

RegisterNetEvent('pape_blipmanager:permissionDenied')
AddEventHandler('pape_blipmanager:permissionDenied', function()
    Notify(Config.NoPermissionMessage, 'error')
end)

function OpenBlipUI()
    local blipArray = {}
    for uid, data in pairs(blips) do
        table.insert(blipArray, data)
    end
    
    isUIOpen = true
    SetNuiFocus(true, true)
    
    SendNUIMessage({
        action = 'open',
        blips = blipArray
    })
end

function CloseBlipUI()
    if not isUIOpen then return end
    
    isUIOpen = false
    SetNuiFocus(false, false)
    
    SendNUIMessage({
        action = 'close'
    })
end

RegisterNUICallback('close', function(data, cb)
    CloseBlipUI()
    cb('ok')
end)

RegisterNUICallback('getCoords', function(data, cb)
    local coords = GetEntityCoords(PlayerPedId())
    
    cb({
        x = math.floor(coords.x * 100) / 100,
        y = math.floor(coords.y * 100) / 100,
        z = math.floor(coords.z * 100) / 100
    })
end)

RegisterNUICallback('createBlip', function(data, cb)
    local uid = "blip_" .. GetGameTimer() .. "_" .. math.random(1000, 9999)
    
    local blipData = {
        uid = uid,
        title = data.title,
        colour = tonumber(data.colour),
        id = tonumber(data.id),
        x = tonumber(data.x),
        y = tonumber(data.y),
        z = tonumber(data.z)
    }
    
    blips[uid] = blipData
    blipHandles[uid] = CreateBlip(blipData)
    
    TriggerServerEvent('pape_blipmanager:createBlip', blipData)
    
    local blipArray = {}
    for k, bdata in pairs(blips) do
        table.insert(blipArray, bdata)
    end
    
    SendNUIMessage({
        action = 'updateBlips',
        blips = blipArray
    })
    
    cb({success = true, uid = uid})
end)

RegisterNUICallback('deleteBlip', function(data, cb)
    local uid = data.uid
    
    if blipHandles[uid] then
        RemoveBlip(blipHandles[uid])
        blipHandles[uid] = nil
    end
    
    blips[uid] = nil
    
    TriggerServerEvent('pape_blipmanager:deleteBlip', uid)
    
    local blipArray = {}
    for k, bdata in pairs(blips) do
        table.insert(blipArray, bdata)
    end
    
    SendNUIMessage({
        action = 'updateBlips',
        blips = blipArray
    })
    
    cb({success = true})
end)

RegisterNetEvent('pape_blipmanager:syncBlip')
AddEventHandler('pape_blipmanager:syncBlip', function(blipData)
    if not blips[blipData.uid] then
        blips[blipData.uid] = blipData
        blipHandles[blipData.uid] = CreateBlip(blipData)
    end
end)

RegisterNetEvent('pape_blipmanager:removeBlip')
AddEventHandler('pape_blipmanager:removeBlip', function(uid)
    if blipHandles[uid] then
        RemoveBlip(blipHandles[uid])
        blipHandles[uid] = nil
    end
    blips[uid] = nil
end)

RegisterNetEvent('pape_blipmanager:loadBlips')
AddEventHandler('pape_blipmanager:loadBlips', function(serverBlips)
    if not serverBlips then return end
    for _, blipData in ipairs(serverBlips) do
        if not blips[blipData.uid] then
            blips[blipData.uid] = blipData
            blipHandles[blipData.uid] = CreateBlip(blipData)
        end
    end
end)

Citizen.CreateThread(function()
    Citizen.Wait(1000)
    TriggerServerEvent('pape_blipmanager:requestBlips')
end)

Citizen.CreateThread(function()
    while true do
        if isUIOpen then
            Citizen.Wait(0)
            DisableControlAction(0, 200, true)
            if IsDisabledControlJustPressed(0, 200) then
                CloseBlipUI()
            end
        else
            Citizen.Wait(500)
        end
    end
end)
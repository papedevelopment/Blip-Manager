CREATE TABLE IF NOT EXISTS `custom_blips` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `uid` VARCHAR(50) NOT NULL,
    `title` VARCHAR(100) NOT NULL,
    `sprite` INT(11) NOT NULL DEFAULT 1,
    `colour` INT(11) NOT NULL DEFAULT 1,
    `x` FLOAT NOT NULL,
    `y` FLOAT NOT NULL,
    `z` FLOAT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;